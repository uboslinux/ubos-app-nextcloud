OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Αναίρεση επιλογής",
    "Share " : "Διαμοιρασμός",
    "Select" : "Επιλογή",
    "Copied !" : "Αντιγράφηκε !",
    "Right click" : "Δεξί κλικ",
    "Right click menu for Nextcloud" : "Μενού δεξί κλικ για το Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Αυτή η εφαρμογή επιτρέπει στους χρήστες και στους προγραμματιστές να έχουν ένα μενού δεξί κλικ. Απλά χρησιμοποιήστε το αντικείμενο RightClick για να δημιουργήσετε γρήγορα μενού περιβάλλοντος. Η εφαρμογή \"Αρχεία\" εμφανίζει ήδη το μενού ενεργειών όταν κάνετε δεξί κλικ σε αρχεία και φακέλους."
},
"nplurals=2; plural=(n != 1);");
