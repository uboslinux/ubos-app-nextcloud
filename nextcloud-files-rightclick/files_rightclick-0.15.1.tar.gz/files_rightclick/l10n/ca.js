OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "No seleccionis",
    "Share " : "Comparteix",
    "Select" : "Selecciona",
    "Copied !" : "S'ha copiat!",
    "Right click" : "Clic amb el botó dret",
    "Right click menu for Nextcloud" : "Feu clic al menú amb el botó dret per Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Aquesta aplicació permet que usuaris i desenvolupadors disposin d'un menú fent clic amb el botó dret. Simplement feu servir l'objecte RightClick per crear menús contextuals ràpidament. L'aplicació Fitxers ja mostra el menú d'accions en fer clic amb el botó dret sobre fitxers i carpetes."
},
"nplurals=2; plural=(n != 1);");
