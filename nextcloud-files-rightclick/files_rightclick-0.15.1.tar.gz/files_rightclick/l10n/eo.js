OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Malelekti",
    "Share " : "Kunhavigi",
    "Select" : "Elekti",
    "Copied !" : "Kopiita!",
    "Right click" : "Dekstra alklako",
    "Right click menu for Nextcloud" : "Dekstralklaka menuo por Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Tiu aplikaĵo disponigas dekstralklakan menuon al uzantoj kaj programistoj. Uzu la objekton „RightClick“ por rapide krei kuntekstajn menuojn. La aplikaĵo „Dosieroj“ jam montras la menuon kun agoj, kiam oni alklakas dekstre dosierojn kaj dosierujojn."
},
"nplurals=2; plural=(n != 1);");
