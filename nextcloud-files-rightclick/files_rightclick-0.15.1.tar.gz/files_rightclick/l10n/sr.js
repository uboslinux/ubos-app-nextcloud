OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Уклони избор",
    "Share " : "Дели",
    "Select" : "Одабери",
    "Copied !" : "Копирано!",
    "Right click" : "Десни клик",
    "Right click menu for Nextcloud" : "Мени десног клика за Некстклауд",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Ова апликација омогућава корисницима и програмерима да добију мени на десни клик. Просто искористите RightClick објекат да брзо направите контекстне меније. Апликација Фајлови већ приказује мени са радњама када се уради десни клик на фајлове и фасцикле."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
