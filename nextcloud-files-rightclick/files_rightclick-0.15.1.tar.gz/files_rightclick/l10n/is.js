OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Afvelja",
    "Share " : "Deila ",
    "Select" : "Velja",
    "Copied !" : "Afritað!",
    "Right click" : "Hægrismella",
    "Right click menu for Nextcloud" : "Hægrismells-valmynd fyrir Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Þetta forrit gerir notendum og forriturum kleift að nota hægrismells-valmynd (samhengisvalmynd). Notaðu einfaldlega RightClick hlutinn til að útbúa samhengisvalmyndir á einfaldan hátt. Skráastjórnunarforritið Files sýnir nú þegar aðgerðavalmynd þegar hægrismellt er á skrár og möppur."
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
