OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "إلغاء التحديد",
    "Share " : "شاركه",
    "Select" : "تحديد",
    "Copied !" : "تم نسخه!",
    "Right click" : "الزر الايمن",
    "Right click menu for Nextcloud" : "قائمة الزر الايمن لنكست كلاود"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
