OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "選択解除",
    "Share " : "共有",
    "Select" : "選択",
    "Copied !" : "コピーしました",
    "Right click" : "右クリック",
    "Right click menu for Nextcloud" : "Nextcloudの右クリックメニュー",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "このアプリでは、ユーザーや開発者が右クリックメニューを利用できるようにします。RightClickオブジェクトを使うだけで、右クリックメニューをすばやく作成できます。ファイルアプリケーションでは、すでにファイルとフォルダを右クリックしたときアクションメニューが表示されています。"
},
"nplurals=1; plural=0;");
