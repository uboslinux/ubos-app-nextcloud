OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Abwählen",
    "Share " : "Teilen",
    "Select" : "Auswählen",
    "Copied !" : "Kopiert!",
    "Right click" : "Rechtsklick",
    "Right click menu for Nextcloud" : "Kontextmenü für Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Diese App ermöglicht es Benutzern, aber auch Entwicklern, ein Rechtsklickmenü zu haben. Verwenden Sie einfach das RightClick-Objekt, um schnell und einfach Menüs zu erstellen. Die Datei-App zeigt bereits das Aktionsmenü an, wenn Sie mit der rechten Maustaste auf Dateien und Ordner klicken."
},
"nplurals=2; plural=(n != 1);");
