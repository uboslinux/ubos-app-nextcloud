OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "سشیبشسیب"
},
"nplurals=2; plural=(n != 1);");
