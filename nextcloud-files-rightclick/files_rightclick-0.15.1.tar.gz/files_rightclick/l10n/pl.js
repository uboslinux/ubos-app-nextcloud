OC.L10N.register(
    "files_rightclick",
    {
    "Unselect" : "Odznacz",
    "Share " : "Udostępnij",
    "Select" : "Wybierz",
    "Copied !" : "Skopiowano !",
    "Right click" : "Kliknij prawym przyciskiem myszy",
    "Right click menu for Nextcloud" : "Kliknij prawym przyciskiem myszy menu Nextcloud",
    "This app allows users and developers to have a right click menu. Simply use the RightClick object to quickly create context menus. The Files app already shows the actions menu when right clicking on files and folders." : "Ta aplikacja pozwala użytkownikom i programistom posiadać menu prawego przycisku myszy. Po prostu użyj obiektu RightClick, aby szybko utworzyć menu kontekstowe. Aplikacja Files posiada już menu akcji po kliknięciu prawym przyciskiem myszy na pliki i katalogi."
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
