<?php
script('text', 'text');
style('text', 'icons');
?>
<div id="app-content">
	<div id="maineditor"></div>
</div>
