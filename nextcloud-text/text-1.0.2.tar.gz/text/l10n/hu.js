OC.L10N.register(
    "text",
    {
    "Text" : "Szöveg",
    "Use current version" : "Aktuális verzió használata",
    "Use the saved version" : "A mentett verzió használata",
    "Last save {lastSave}" : "Utolsó mentés {lastSave}",
    "Unsaved changes" : "Mentetlen változtatások",
    "Enter your name so other users can see who is editing" : "Add meg a neved, hogy mások lássák ki szerkeszti",
    "Edit guest name" : "Vendég név szerkesztése",
    "Save guest name" : "Vendég név mentése",
    "Add link" : "Hivatkozás hozzáadása",
    "Show image" : "Kép megjelenítése",
    "Show file" : "Fájl megjelenítése",
    "New text document" : "Új szöveg dokumentum",
    "New text document.md" : "Új szöveg dokumentum.md",
    "Edit" : "Szerkesztés",
    "Undo" : "Visszavon"
},
"nplurals=2; plural=(n != 1);");
